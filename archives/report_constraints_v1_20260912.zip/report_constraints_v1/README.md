# 报告语义约束 v1

独立的第二阶段实验：报告正文 → 前提 / 安全性质 / 声称效果 → 类型化表达式 AST → 只读代码绑定 → 局部求解检查。不修改切片器，不运行 InvCon/Trace2Inv，不替代第三阶段或判断报告真假。

当前结果及归档说明见 [V1_REPORT.md](V1_REPORT.md)。[EXPERIMENT_REPORT.md](EXPERIMENT_REPORT.md) 保留最初 #461 实验记录，其中原始绝对路径及下一步计划属于历史记录。

两份样例：Hypovault #461（正文给出权利金关系）；Next Core #698（需推导攻击前权限与攻击后余额关系）。抽取不提供 PoC、修复建议或有效性标签。#698 去除代码块及链接 URL 以减少输入，保留正文散文；不是完整报告全文推理。

符号含义及表达式语法预先限定，安全公式与效果公式由模型推导，不提供固定漏洞性质模板。代码绑定是样例专用适配器，不是通用 Solidity 解析器。

## 目录

```text
smoke.py / test_smoke.py    #461 初始实验及测试
v1.py / test_v1.py          #698 时序声明及效果约束
verify_v1.py               零模型调用复验保存结果和 SMT 文件
archive_v1.py              打包并验证 SHA-256 清单
prepare_v1.py              初次快照工具，归档使用时无需运行
samples/                   两份完整报告、展开 PoC、配对及来源信息
results/v1/                尝试记录、模型输出、用量及 SMT 查询
```

样例已复制到本目录，原始路径只是来源记录。离线验证不依赖 `/root/poc_repro_work`。

## 离线验证：不消耗模型 token

使用现有 Halmos Python，其中已有 Z3，无需安装依赖：

```bash
cd /root/sc_slicer_standalone
/root/.local/share/uv/tools/halmos/bin/python tools/report_constraints/verify_v1.py

/root/.local/share/uv/tools/halmos/bin/python -m unittest discover \
  -s tools/report_constraints -p 'test_*.py' -v
```

复用保存的 #698 抽取结果重新生成约束和 SMT：

```bash
/root/.local/share/uv/tools/halmos/bin/python tools/report_constraints/v1.py \
  --replay tools/report_constraints/results/v1/panoptic_698_final \
  --output runs/report_constraints/v1_replay_NEW_ID
```

所有输出目录必须不存在，避免覆盖旧记录。解压归档后可在模块目录直接运行 `verify_v1.py` 和 `unittest discover -s .`；需要 Python 3.10+ 和兼容的 `z3-solver`，不需要 opencode 或密钥。

## 如需重新调用模型

```bash
/root/.local/share/uv/tools/halmos/bin/python tools/report_constraints/v1.py \
  --model opencode-go/deepseek-v4-flash \
  --output runs/report_constraints/v1_online_NEW_ID
```

不传 `--model` 时读取原工程 `config/llm.env` 的模型名。鉴权复用 opencode 已有配置，不读取或打印 API key。调用关闭插件、禁止 agent 工具，并在临时目录运行；沙箱内可能需要允许服务访问及 opencode 缓存写入。一次 CLI 最多调用模型一次，没有自动无限重试；`--repair FAILED_RESULT_DIR` 可显式做一次带反馈抽取。

## 输出接口

`v1.py` 输出布尔 `precondition`、`safety_property`、`claimed_effect`、原文依据、假设、未解决项、代码位置、输入哈希、求解证据和用量。支持 `eq/ne`、数值比较、`add/sub`、`and/or/not/implies`，区分地址、token 数量和布尔。#461 的初始 schema 单独保留，不声称接口已经统一。

余额检查点为攻击者 `init` 前 / `sweep` 后，管理员检查点为攻击者 `init` 前 / 后。检查原模型可行、安全性质违反、声称效果及其反例；使用禁止重初始化、删除 sweep 的模型对照检查弱效果约束。`queries/*.smt2` 可离线执行，但含手写局部执行模型，不是从完整 Solidity 自动编译得到的。

## v1 冻结边界

仅两个样例；原文引用存在不代表推导语义正确。#461 仅建模 uint128 权利金转 int256 后的安全减法，不证明完整 NAV；#698 固定初始化钱包和 `1e18` token 余额场景，假设标准 ERC20 成功转账，无手续费、回调或中间操作。

未接入第一阶段切片；未覆盖全协议费用流、赎回或真实资金损失。不做微调、RAG、知识库或自动真假分类。v1 归档前停止扩展。

## 打包归档

```bash
python3 tools/report_constraints/archive_v1.py \
  --output archives/report_constraints_v1_NEW_ID.zip
```

只打包本模块的源码、文档、样例及结果，排除缓存，不包含工程配置、登录数据或密钥。ZIP 内的 `ARCHIVE_MANIFEST.json` 记录文件大小和 SHA-256，打包后检查 CRC 和内容哈希，不覆盖已有归档。样例保留来源及原有许可证声明；外部发布前应核对代码许可和报告使用条件。

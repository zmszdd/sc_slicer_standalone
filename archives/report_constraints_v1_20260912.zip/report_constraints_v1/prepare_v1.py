"""Snapshot two paired cases and the initial result; never replaces existing data."""
import json
from pathlib import Path
import shutil

HERE = Path(__file__).resolve().parent
BASE = Path('/root/poc_repro_work/verified_flatten_pass_1568_exact_cases')
CASES = {
    'panoptic_461': 'Panoptic_Hypovault_c9MhophgwGP__F87EJt3PoCN__aHe7XWv2GNE',
    'panoptic_698': 'Panoptic__Next_Core_iqcUwAhCZyD__CUEQdPu878N__B8xcHpQr2Gb',
}


def main():
    targets = [HERE / 'samples' / name for name in CASES]
    initial_result = HERE / 'results/v1/panoptic_461'
    if any(path.exists() for path in targets + [initial_result]):
        raise SystemExit('snapshot exists; no files replaced')
    for name, dirname in CASES.items():
        source = BASE / dirname
        target = HERE / 'samples' / name
        target.mkdir(parents=True)
        for filename in ('report.json', 'report.md', 'metadata.json', 'contract.flattened.t.sol'):
            shutil.copy2(source / filename, target / filename)
        (target / 'ORIGIN.json').write_text(json.dumps({
            'original_directory': str(source), 'snapshot_version': 'v1',
            'note': 'Original paths are provenance only; local snapshot is the input.',
        }, indent=2) + '\n')
    original = HERE.parents[1] / 'runs/report_constraints/panoptic_461_smoke_20260912_02'
    shutil.copytree(original, initial_result)
    print('snapshotted 2 paired cases and the initial result')


if __name__ == '__main__':
    main()

; benchmark generated from python API
(set-info :status unknown)
(declare-fun actor () Int)
(declare-fun admin_before () Int)
(declare-fun admin_after () Int)
(declare-fun wallet_before () Int)
(declare-fun wallet_after () Int)
(declare-fun attacker_before () Int)
(declare-fun attacker_after () Int)
(assert
 (>= actor 0))
(assert
 (>= admin_before 0))
(assert
 (>= admin_after 0))
(assert
 (>= wallet_before 0))
(assert
 (>= wallet_after 0))
(assert
 (>= attacker_before 0))
(assert
 (>= attacker_after 0))
(assert
 (< actor 1461501637330902918203684832716283019655932542976))
(assert
 (< admin_before 1461501637330902918203684832716283019655932542976))
(assert
 (< admin_after 1461501637330902918203684832716283019655932542976))
(assert
 (< wallet_before 115792089237316195423570985008687907853269984665640564039457584007913129639936))
(assert
 (< wallet_after 115792089237316195423570985008687907853269984665640564039457584007913129639936))
(assert
 (< attacker_before 115792089237316195423570985008687907853269984665640564039457584007913129639936))
(assert
 (< attacker_after 115792089237316195423570985008687907853269984665640564039457584007913129639936))
(assert
 (= actor 3))
(assert
 (= admin_before 2))
(assert
 (= wallet_before 1000000000000000000))
(assert
 (= attacker_before 0))
(assert
 (let (($x36 (and (distinct actor admin_before) true)))
 (and $x36 (< 0 wallet_before))))
(assert
 (= admin_after actor))
(assert
 (= wallet_after wallet_before))
(assert
 (= attacker_after attacker_before))
(assert
 (and (= 0 wallet_after) (= attacker_after (+ attacker_before wallet_before))))
(check-sat)

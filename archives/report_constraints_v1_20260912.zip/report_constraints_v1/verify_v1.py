"""Recheck both saved experiments and SMT files offline; no opencode invocation."""
import json
from pathlib import Path

import z3
from smoke import bind, digest, solve, validate_claim
from v1 import bind_wallet, load_case, prose_only, solve_wallet, validate

HERE = Path(__file__).resolve().parent


def main():
    summary = {}
    case = HERE / 'samples/panoptic_461'
    report, _ = load_case(case)
    saved = json.loads((HERE / 'results/v1/panoptic_461/constraints.json').read_text())
    if digest(case / 'report.json') != saved['report_sha256']:
        raise ValueError('initial report hash mismatch')
    if digest(case / 'contract.flattened.t.sol') != saved['code_sha256']:
        raise ValueError('initial source hash mismatch')
    claim = saved['claims']
    raw = json.loads((HERE / 'results/v1/panoptic_461/model-claim.json').read_text())
    if raw != claim: raise ValueError('initial constraints differ from model output')
    validate_claim(claim, report['body'].split('## Recommended mitigation steps')[0].strip())
    impl, _ = bind((case / 'contract.flattened.t.sol').read_text())
    results, passed, _ = solve(claim, impl)
    summary['panoptic_461'] = {'passed': passed, 'checks': len(results)}

    case = HERE / 'samples/panoptic_698'
    report, _ = load_case(case)
    result_dir = HERE / 'results/v1/panoptic_698_final'
    saved = json.loads((result_dir / 'constraints.json').read_text())
    claim = saved['claims']
    if json.loads((result_dir / 'model-claim.json').read_text()) != claim:
        raise ValueError('final constraints differ from model output')
    prose = prose_only(report['body'])
    import hashlib
    if hashlib.sha256(prose.encode()).hexdigest() != saved['report_prose_sha256']:
        raise ValueError('prose hash mismatch')
    validate(claim, prose)
    bind_wallet((case / 'contract.flattened.t.sol').read_text())
    results, passed, _ = solve_wallet(claim)
    smt_checks = 0
    for name, original in saved['queries'].items():
        solver = z3.Solver()
        solver.set(timeout=5000)
        solver.from_file(str(result_dir / original['smt2_file']))
        if str(solver.check()) != original['result'] or original['result'] != results[name]['result']:
            raise ValueError('SMT replay differs: ' + name)
        smt_checks += 1
    summary['panoptic_698'] = {'passed': passed, 'checks': len(results), 'smt_files': smt_checks}
    print(json.dumps({'llm_calls': 0, 'cases': summary}, indent=2))
    if not all(value['passed'] for value in summary.values()):
        raise SystemExit(1)


if __name__ == '__main__': main()

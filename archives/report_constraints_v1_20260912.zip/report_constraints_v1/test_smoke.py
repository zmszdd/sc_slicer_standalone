"""Offline checks for the smoke adapter; never calls an LLM."""
import copy
import unittest

from smoke import bind, solve, validate_claim, validate_expr


def var(name):
    return {'var': name}


def requirement():
    return {'op': 'eq', 'args': [var('actual_token1_exposure'),
            {'op': 'sub', 'args': [var('short_token1'), var('long_token1')]}]}


class SmokeTests(unittest.TestCase):
    def test_typed_requirement(self):
        self.assertEqual(validate_expr(requirement()), 'bool')

    def test_unknown_symbol_rejected(self):
        with self.assertRaises(ValueError):
            validate_expr(var('hallucinated_balance'))

    def test_unknown_operator_rejected(self):
        with self.assertRaises(ValueError):
            validate_expr({'op': 'execute', 'args': [var('short_token1'), var('long_token1')]})

    def test_boolean_arithmetic_rejected(self):
        with self.assertRaises(ValueError):
            validate_expr({'op': 'sub', 'args': [requirement(), var('short_token1')]})

    def test_invented_quote_rejected(self):
        claim = {'safety_property': requirement(), 'safety_evidence': 'invented',
                 'claimed_effect_text': 'wrong exposure', 'effect_evidence': 'wrong',
                 'unresolved': []}
        with self.assertRaises(ValueError):
            validate_claim(claim, 'wrong exposure')

    def test_missing_binding_rejected(self):
        with self.assertRaises(ValueError):
            bind('contract Unrelated {}')

    def test_original_and_corrected_formula(self):
        implementation = {'op': 'sub', 'args': [var('long_token1'), var('short_token1')]}
        results, passed, _ = solve({'safety_property': requirement()}, implementation)
        self.assertTrue(passed)
        self.assertEqual(results['corrected_formula_any_safety_violation']['result'], 'unsat')

    def test_wrong_extraction_does_not_pass_sanity(self):
        wrong = copy.deepcopy(requirement())
        wrong['args'][1]['args'].reverse()
        implementation = {'op': 'sub', 'args': [var('long_token1'), var('short_token1')]}
        _, passed, _ = solve({'safety_property': wrong}, implementation)
        self.assertFalse(passed)


if __name__ == '__main__':
    unittest.main()

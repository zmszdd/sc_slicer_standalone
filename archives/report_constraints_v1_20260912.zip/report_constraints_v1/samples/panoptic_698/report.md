# Attacker can steal all builder fees by taking over the builder wallet

- Match status: `exact_submission`
- Project: `Panoptic_ Next Core_iqcUwAhCZyD`
- Submission UID: `B8xcHpQr2Gb`
- Finding UID: `CUEQdPu878N`
- Severity: `high`
- Validity: `valid`
- Quality: `sufficient`
- Source: `/root/sc_slicer_standalone/c4_pipeline_output/Panoptic_Next_Core_iqcUwAhCZyD/20260618_141146/findings.json`

> The report is the exact submission paired with this contract.

## Report body

## Finding description and impact

The protocol routes a portion of commission fees to a per-builder fee recipient. During option mint/burn settlement, `CollateralTracker` transfers the builder’s split of shares to `address(uint160(riskParameters.feeRecipient()))` in both [`settleMint()`](https://github.com/code-423n4/2025-12-panoptic/blob/fe557748210a529ae414d7c487b6514be0d9e220/contracts/CollateralTracker.sol#L1531-L1532) and [`settleBurn()`](https://github.com/code-423n4/2025-12-panoptic/blob/fe557748210a529ae414d7c487b6514be0d9e220/contracts/CollateralTracker.sol#L1595-L1596) (`contracts/CollateralTracker.sol:1531-1584`, `contracts/CollateralTracker.sol:1595-1663`). 

[CollateralTracker.sol#L1568-L1572](https://github.com/code-423n4/2025-12-panoptic/blob/fe557748210a529ae414d7c487b6514be0d9e220/contracts/CollateralTracker.sol#L1568-L1572)
```solidity
                    _transferFrom(
                        optionOwner,
                        address(uint160(riskParameters.feeRecipient())),
                        (sharesToBurn * riskParameters.builderSplit()) / DECIMALS
                    );
```

The `feeRecipient` value is derived from [`RiskEngine.getRiskParameters()`](https://github.com/code-423n4/2025-12-panoptic/blob/fe557748210a529ae414d7c487b6514be0d9e220/contracts/RiskEngine.sol#L864-L886), which computes a deterministic builder wallet address using a `CREATE2` formula.

[RiskEngine.sol#L871-L872](https://github.com/code-423n4/2025-12-panoptic/blob/fe557748210a529ae414d7c487b6514be0d9e220/contracts/RiskEngine.sol#L871-L872)
```solidity
        uint128 feeRecipient = uint256(uint160(_computeBuilderWallet(builderCode))).toUint128();
```

That builder wallet is implemented as `BuilderWallet` in `contracts/RiskEngine.sol`. It is intended to let an authorized builder admin withdraw accumulated tokens via [`sweep()`](https://github.com/code-423n4/2025-12-panoptic/blob/fe557748210a529ae414d7c487b6514be0d9e220/contracts/RiskEngine.sol#L2319-L2330) which checks `msg.sender == builderAdmin` .

The root cause is that [`BuilderWallet.init()`](https://github.com/code-423n4/2025-12-panoptic/blob/fe557748210a529ae414d7c487b6514be0d9e220/contracts/RiskEngine.sol#L2315-L2317) is an `external` function that sets `builderAdmin` with no access control and no one-time initialization guard. 
```solidity
    function init(address _builderAdmin) external {
        builderAdmin = _builderAdmin;
    }
```
This allows any account to overwrite `builderAdmin` at any time, then call `sweep()` to drain any ERC20 balance held by the wallet.

The highest-impact scenario is straightforward: once fees have been routed into a builder wallet (e.g., CollateralTracker share tokens representing real underlying value), an attacker sets themselves as `builderAdmin` via `init()` and drains the wallet via `sweep()`. This is repeatable since the admin can be overwritten again later.

> [!NOTE]
Even though `BuilderWallet` stores an immutable `FACTORY`, it is not used to restrict `init()`, so it provides no protection against this takeover.

## Impact
High , an unprivileged attacker can directly steal all assets held by a builder fee recipient wallet.


## Recommended mitigation steps
Restrict `init()` to the deploying factory (e.g., require `msg.sender == FACTORY`) and enforce one-time initialization (e.g., require `builderAdmin == address(0)`), or set the admin immutably during deployment.

## Proof of Concept

Add the PoC test as `test_POC_BuilderWalletInitPermissionless_AllowsSweep()` in `test/foundry/core/RiskEngine/RiskEngine.Scenarios.t.sol`

1. Import these
```solidity
import {BuilderWallet} from "@contracts/RiskEngine.sol";
import {ERC20S} from "../../testUtils/ERC20S.sol";
```
2. Add PoC test
```solidity
function test_POC_BuilderWalletInitPermissionless_AllowsSweep() public {
        address factory = address(0xFACA);
        BuilderWallet wallet = new BuilderWallet(factory);

        address legitAdmin = address(0xA11CE);
        wallet.init(legitAdmin);

        ERC20S token = new ERC20S("Token", "TKN", 18);
        uint256 amount = 1e18;
        token.mint(address(wallet), amount);

        address attacker = address(0xB0B);
        vm.prank(attacker);
        wallet.init(attacker);

        vm.prank(attacker);
        wallet.sweep(address(token), attacker);

        assertEq(wallet.builderAdmin(), attacker);
        assertEq(token.balanceOf(attacker), amount);
        assertEq(token.balanceOf(address(wallet)), 0);
    }
```
Run: `forge test --match-test test_POC_BuilderWalletInitPermissionless_AllowsSweep -vvv`

The test deploys a `BuilderWallet`, mints an `ERC20S` balance to it, then has an attacker call `init()` to overwrite `builderAdmin` and successfully call `sweep()` to transfer the full balance to the attacker.

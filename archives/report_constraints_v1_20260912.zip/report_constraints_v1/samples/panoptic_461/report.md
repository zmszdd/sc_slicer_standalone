# token1 premium cash-flows counted with the wrong sign, vault NAV can be off by the full value of all premiums

- Match status: `exact_submission`
- Project: `Panoptic Hypovault_c9MhophgwGP`
- Submission UID: `aHe7XWv2GNE`
- Finding UID: `F87EJt3PoCN`
- Severity: `medium`
- Validity: `valid`
- Quality: `sufficient`
- Source: `/root/sc_slicer_standalone/c4_pipeline_output/Panoptic_Hypovault_c9MhophgwGP/20260618_092947/findings.json`

> The report is the exact submission paired with this contract.

## Report body

## Finding description and impact

The contract retrieves premium data through the `getAccumulatedFeesAndPositionsData` function, which returns two `LeftRightUnsigned` structures representing accumulated fees for short and long positions. These structures use a consistent slot convention where `rightSlot()` contains `token0` amounts and `leftSlot()` contains `token1` amounts.
The current implementation calculates pool exposure from premiums as follows:
```solidity
poolExposure0 = int256(uint256(shortPremium.rightSlot())) - int256(uint256(longPremium.rightSlot()));
poolExposure1 = int256(uint256(longPremium.leftSlot())) - int256(uint256(shortPremium.leftSlot()));
```
The issue lies in the asymmetric treatment of token0 versus token1 premium calculations. While both calculations should follow identical accounting principles, they currently use opposite sign conventions

`Token0 Calculation (Correct):`

Formula: `shortPremium - longPremium`
Economic meaning: `fees_earned - fees_paid`
This correctly represents net cash flow where earned fees increase exposure and paid fees decrease exposure

`Token1 Calculation (Incorrect):`

Formula: `longPremium - shortPremium`
Economic meaning: `fees_paid - fees_earned`
This incorrectly inverts the cash flow relationship

This is wrong because Short premiums are money the vault receives → should increase NAV. Long premiums are money the vault pays → should decrease NAV.

By subtracting in the opposite order for token 1, the contract adds liabilities and subtracts assets, flipping their economic meaning. It also misstates NAV by twice the premium amount whenever trades are denominated in token 1.

## Recommended mitigation steps

Correct the asymmetric premium calculation by aligning both token0 and token1 formulas to use the same accounting convention:
```solidity
poolExposure0 = int256(uint256(shortPremium.rightSlot())) - int256(uint256(longPremium.rightSlot()));
poolExposure1 = int256(uint256(shortPremium.leftSlot())) - int256(uint256(longPremium.leftSlot()));
```

## Proof of Concept

This test proves that vaults collecting token1 option premiums are systematically undervaluing their assets

```solidity
// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.0;

import "forge-std/Test.sol";
import "./HypoVault.t.sol";
import "./PanopticVaultAccountant.t.sol";
import {LeftRightUnsigned} from "lib/panoptic-v1.1/contracts/types/LeftRight.sol";
import {TokenId} from "lib/panoptic-v1.1/contracts/types/TokenId.sol";

contract PoC is Test {
    // Vault Data
    VaultAccountantMock public mockAccountant;
    HypoVault public vault;
    ERC20S public token;
    
    // Accountant Data
    PanopticVaultAccountant public accountant;
    MockERC20Partial public token0;
    MockERC20Partial public token1;
    MockERC20Partial public underlyingToken;
    MockV3CompatibleOracle public poolOracle;
    MockV3CompatibleOracle public oracle0;
    MockV3CompatibleOracle public oracle1;
    MockPanopticPool public mockPool;
    
    // Test Addresses
    address Manager = address(0x1234);
    address FeeWallet = address(0x5678);
    address Alice = address(0x123456);
    address Bob = address(0x12345678);
    address Charlie = address(0x1234567891);
    address Dave = address(0x12345678912);
    address Eve = address(0x123456789123);
    
    // Test Parameters
    uint256 constant INITIAL_BALANCE = 1000000 ether;
    uint256 constant BOOTSTRAP_SHARES = 1_000_000;
    int24 constant TWAP_TICK = 100;
    int24 constant MAX_PRICE_DEVIATION = 50;
    uint32 constant TWAP_WINDOW = 600; // 10 minutes
    
    function setUp() public {
        mockAccountant = new VaultAccountantMock();
        token = new ERC20S("Test Token", "TEST", 18);
        vault = new HypoVault(address(token), Manager, IVaultAccountant(address(mockAccountant)), 100); // 1% performance fee
        
        // Set fee wallet
        vault.setFeeWallet(FeeWallet);
        
        // Mint tokens and approve vault for all users
        address[6] memory users = [Alice, Bob, Charlie, Dave, Eve, Manager];
        for (uint i = 0; i < users.length; i++) {
            token.mint(users[i], INITIAL_BALANCE);
            vm.prank(users[i]);
            token.approve(address(vault), type(uint256).max);
        }
        
        accountant = new PanopticVaultAccountant();
        token0 = new MockERC20Partial("Token0", "T0");
        token1 = new MockERC20Partial("Token1", "T1");
        underlyingToken = new MockERC20Partial("Underlying", "UND");
        poolOracle = new MockV3CompatibleOracle();
        oracle0 = new MockV3CompatibleOracle();
        oracle1 = new MockV3CompatibleOracle();
        mockPool = new MockPanopticPool();
        
        // Setup default oracle behavior
        _setupDefaultOracles();
    }
    
    function _setupDefaultOracles() internal {
        // Setup consistent tick cumulatives for TWAP calculation
        int56[] memory defaultTicks = new int56[](20);
        uint32 intervalDuration = TWAP_WINDOW / 20; // 30 seconds
        
        // Create tick cumulatives that will result in TWAP_TICK when filtered
        for (uint i = 0; i < 20; i++) {
            defaultTicks[i] = int56(
                int256(TWAP_TICK) * int256(uint256(intervalDuration)) * int256(20 - i)
            );
        }
        
        poolOracle.setTickCumulatives(defaultTicks);
        oracle0.setTickCumulatives(defaultTicks);
        oracle1.setTickCumulatives(defaultTicks);
    }
    
    function test_submissionValidity() external {
        console.log("=== Asymmetric Premium Calculation Vulnerability PoC ===");
        
        address testVault = address(0x9999);
        
        // Give vault base balance in underlying token
        underlyingToken.setBalance(testVault, 1000 ether);
        
        // Setup pool info
        PanopticVaultAccountant.PoolInfo memory poolInfo = PanopticVaultAccountant.PoolInfo({
            pool: PanopticPool(address(mockPool)),
            token0: token0,
            token1: token1,
            poolOracle: poolOracle,
            oracle0: oracle0,
            isUnderlyingToken0InOracle0: true,
            oracle1: oracle1,
            isUnderlyingToken0InOracle1: false,
            maxPriceDeviation: MAX_PRICE_DEVIATION,
            twapWindow: TWAP_WINDOW
        });
        
        PanopticVaultAccountant.PoolInfo[] memory pools = new PanopticVaultAccountant.PoolInfo[](1);
        pools[0] = poolInfo;
        
        PanopticVaultAccountant.ManagerPrices[] memory managerPrices = new PanopticVaultAccountant.ManagerPrices[](1);
        managerPrices[0] = PanopticVaultAccountant.ManagerPrices({
            poolPrice: TWAP_TICK,
            token0Price: TWAP_TICK,
            token1Price: TWAP_TICK
        });
        
        // Create a simple position
        TokenId[] memory tokenIds = new TokenId[](1);
        tokenIds[0] = TokenId.wrap(0)
            .addPoolId(1)
            .addTickSpacing(60)
            .addLeg({
                legIndex: 0,
                _optionRatio: 1,
                _asset: 0,
                _isLong: 0,
                _tokenType: 0,
                _riskPartner: 0,
                _strike: TWAP_TICK,
                _width: 100
            });
        
        TokenId[][] memory allTokenIds = new TokenId[][](1);
        allTokenIds[0] = tokenIds;
        
        // Mock position data
        uint256[2][] memory positionData = new uint256[2][](1);
        positionData[0] = [uint256(0), uint256(1000)];
        mockPool.setMockPositionBalanceArray(positionData);
        mockPool.setNumberOfLegs(testVault, 1);
        
        // Setup pools hash
        bytes32 poolsHash = keccak256(abi.encode(pools));
        vm.prank(accountant.owner());
        accountant.updatePoolsHash(testVault, poolsHash);
        
        console.log("\n=== Test 1: Baseline (No Premiums) ===");
        
        // First test: No premiums
        mockPool.setMockPremiums(
            LeftRightUnsigned.wrap(0),
            LeftRightUnsigned.wrap(0)
        );
        
        bytes memory managerInput = abi.encode(managerPrices, pools, allTokenIds);
        uint256 baselineNav = accountant.computeNAV(testVault, address(underlyingToken), managerInput);
        console.log("NAV with no premiums:", baselineNav);
        console.log("(This is our baseline including the 1000 ether underlying balance)");
        
        console.log("\n=== Test 2: Token0 Premiums Only ===");
        
        // Test with only token0 premiums
        uint256 shortPremium0 = 100 ether;
        uint256 longPremium0 = 40 ether;
        
        mockPool.setMockPremiums(
            LeftRightUnsigned.wrap(shortPremium0), // Only token0 in rightSlot
            LeftRightUnsigned.wrap(longPremium0)   // Only token0 in rightSlot
        );
        
        uint256 token0Nav = accountant.computeNAV(testVault, address(underlyingToken), managerInput);
        console.log("Short premium (token0): 100 ether");
        console.log("Long premium (token0): 40 ether");
        console.log("Net premium: 100 - 40 = 60 ether");
        console.log("NAV with token0 premiums:", token0Nav);
        console.log("Increase from baseline:", token0Nav - baselineNav);
        
        console.log("\n=== Test 3: Token1 Premiums Only ===");
        
        // Test with only token1 premiums (same amounts)
        uint256 shortPremium1 = 100 ether;
        uint256 longPremium1 = 40 ether;
        
        mockPool.setMockPremiums(
            LeftRightUnsigned.wrap(shortPremium1 << 128), // Only token1 in leftSlot
            LeftRightUnsigned.wrap(longPremium1 << 128)   // Only token1 in leftSlot
        );
        
        uint256 token1Nav = accountant.computeNAV(testVault, address(underlyingToken), managerInput);
        console.log("Short premium (token1): 100 ether");
        console.log("Long premium (token1): 40 ether");
        console.log("Net premium: 100 - 40 = 60 ether");
        console.log("NAV with token1 premiums:", token1Nav);
        
        if (token1Nav > baselineNav) {
            console.log("Increase from baseline:", token1Nav - baselineNav);
        } else {
            console.log("DECREASE from baseline:", baselineNav - token1Nav);
        }
        
        console.log("\n=== VULNERABILITY CHECK ===");
        console.log("Token0 impact on NAV:", int256(token0Nav) - int256(baselineNav));
        console.log("Token1 impact on NAV:", int256(token1Nav) - int256(baselineNav));
        
        // Check if token1 premiums have proper impact
        int256 token0Impact = int256(token0Nav) - int256(baselineNav);
        int256 token1Impact = int256(token1Nav) - int256(baselineNav);
        
        if (token1Impact <= 0 && shortPremium1 > longPremium1) {
            console.log("\n*** VULNERABILITY CONFIRMED ***");
            if (token1Impact < 0) {
                console.log("Token1 premiums are DECREASING NAV instead of increasing it!");
            } else {
                console.log("Token1 premiums have ZERO impact on NAV when they should increase it!");
            }
            console.log("The calculation is inverted for token1.");
        } else if (token0Impact > 0 && token1Impact > 0) {
            console.log("\n*** VULNERABILITY FIXED ***");
            console.log("Both token0 and token1 premiums correctly increase NAV.");
        } else {
            console.log("\n*** UNEXPECTED RESULT ***");
            console.log("Please check the test setup.");
        }
        
        console.log("\n=== Test 4: Large Token1 Premium (Extreme Case) ===");
        
        // Extreme case: 1000 ether short premium
        mockPool.setMockPremiums(
            LeftRightUnsigned.wrap(1000 ether << 128), // 1000 ether token1 short premium
            LeftRightUnsigned.wrap(0)
        );
        
        uint256 extremeNav = accountant.computeNAV(testVault, address(underlyingToken), managerInput);
        console.log("Vault collected 1000 ether in token1 short premiums");
        console.log("NAV:", extremeNav);
        console.log("Change from baseline:", int256(extremeNav) - int256(baselineNav));
        
        if (int256(extremeNav) < int256(baselineNav)) {
            console.log("*** Collecting fees REDUCED NAV by", baselineNav - extremeNav);
        } else if (extremeNav == baselineNav) {
            console.log("*** Collecting 1000 ether in fees had ZERO impact on NAV!");
        } else {
            console.log("Collecting fees correctly increased NAV by", extremeNav - baselineNav);
        }
    }
}
```

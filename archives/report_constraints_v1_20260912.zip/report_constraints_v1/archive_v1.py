"""Package this module only, with SHA-256 manifest; no credentials or caches."""
import argparse
import hashlib
import json
from pathlib import Path
import zipfile

HERE = Path(__file__).resolve().parent
SUFFIXES = {'.py', '.md', '.json', '.txt', '.sol', '.smt2'}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    if args.output.exists(): parser.error('archive already exists; no overwrite')
    files = sorted(p for p in HERE.rglob('*') if p.is_file()
                   and p.suffix in SUFFIXES
                   and not any(part.startswith('.') or part == '__pycache__'
                               for part in p.relative_to(HERE).parts))
    manifest = {'version': 'v1', 'root': 'report_constraints_v1',
                'credentials_included': False, 'files': [
                    {'path': str(p.relative_to(HERE)), 'bytes': p.stat().st_size,
                     'sha256': hashlib.sha256(p.read_bytes()).hexdigest()} for p in files]}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(args.output, 'x', zipfile.ZIP_DEFLATED) as archive:
        for path in files:
            archive.write(path, 'report_constraints_v1/' + str(path.relative_to(HERE)))
        archive.writestr('report_constraints_v1/ARCHIVE_MANIFEST.json',
                         json.dumps(manifest, indent=2) + '\n')
    with zipfile.ZipFile(args.output) as archive:
        if archive.testzip() is not None: raise ValueError('archive CRC check failed')
        for item in manifest['files']:
            content = archive.read('report_constraints_v1/' + item['path'])
            if hashlib.sha256(content).hexdigest() != item['sha256']:
                raise ValueError('archive hash mismatch')
    print(json.dumps({'archive': str(args.output), 'files': len(files),
                      'bytes': args.output.stat().st_size, 'hashes_verified': True}, indent=2))


if __name__ == '__main__': main()

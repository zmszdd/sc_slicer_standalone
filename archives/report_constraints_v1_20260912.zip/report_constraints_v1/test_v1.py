"""Offline V1 tests. Fixtures are test expectations, never LLM output substitutes."""
import copy
import unittest

from v1 import bind_wallet, infer_type, load_case, prose_only, solve_wallet, validate, HERE


def var(name): return {'var': name}
def op(name, *args): return {'op': name, 'args': list(args)}


def fixture():
    return {
        'precondition': op('and', op('ne', var('actor'), var('admin_before')),
                           op('gt', var('wallet_before'), {'const': 0})),
        'safety_property': op('eq', var('wallet_after'), var('wallet_before')),
        'claimed_effect': op('and', op('eq', var('admin_after'), var('actor')),
                             op('eq', var('wallet_after'), {'const': 0}),
                             op('eq', op('sub', var('attacker_after'), var('attacker_before')),
                                var('wallet_before'))),
        'precondition_evidence': 'unprivileged attacker',
        'safety_evidence': 'authorized admin', 'effect_evidence': 'steal all assets',
        'assumptions': [], 'unresolved': [],
    }


class V1Tests(unittest.TestCase):
    def test_valid_fixture(self):
        validate(fixture(), 'authorized admin; unprivileged attacker; steal all assets')

    def test_address_amount_mismatch(self):
        with self.assertRaises(ValueError):
            infer_type(op('eq', var('actor'), var('wallet_before')))

    def test_boolean_constant_not_amount(self):
        with self.assertRaises(ValueError): infer_type({'const': True})

    def test_numeric_top_level_rejected(self):
        claim = fixture()
        claim['safety_property'] = var('wallet_before')
        with self.assertRaises(ValueError): validate(claim, 'authorized admin')

    def test_unknown_identifier(self):
        with self.assertRaises(ValueError): infer_type(var('totalSupply'))

    def test_no_poc_or_fix_in_prose(self):
        text = 'description\n```solidity\nsecret_code();\n```\n## Recommended mitigation steps\nfix'
        prose = prose_only(text)
        self.assertNotIn('secret_code', prose)
        self.assertNotIn('fix', prose)

    def test_temporal_security_and_effect_controls(self):
        results, passed, _ = solve_wallet(fixture())
        self.assertTrue(passed)
        self.assertEqual(results['no_sweep_claimed_effect']['result'], 'unsat')

    def test_current_admin_rule_is_not_intended_security(self):
        claim = fixture()
        claim['safety_property'] = op('eq', var('actor'), var('admin_after'))
        _, passed, _ = solve_wallet(claim)
        self.assertFalse(passed)

    def test_vacuous_precondition_fails(self):
        claim = fixture()
        claim['precondition'] = op('eq', var('actor'), var('admin_before'))
        results, passed, _ = solve_wallet(claim)
        self.assertEqual(results['original_nonempty']['result'], 'unsat')
        self.assertFalse(passed)

    def test_weak_admin_only_effect_does_not_pass(self):
        claim = copy.deepcopy(fixture())
        claim['claimed_effect'] = op('eq', var('admin_after'), var('actor'))
        _, passed, _ = solve_wallet(claim)
        self.assertFalse(passed)

    def test_archived_pairing_is_verified(self):
        report, _ = load_case(HERE / 'samples/panoptic_698')
        self.assertEqual(report['submission_uid'], 'B8xcHpQr2Gb')

    def test_missing_wallet_binding_rejected(self):
        with self.assertRaises(ValueError): bind_wallet('contract Unrelated {}')

    def test_generated_smt_can_be_replayed(self):
        import z3
        results, _, _ = solve_wallet(fixture())
        for outcome in results.values():
            solver = z3.Solver()
            solver.set(timeout=5000)
            solver.from_string(outcome['smt2'])
            self.assertEqual(str(solver.check()), outcome['result'])


if __name__ == '__main__': unittest.main()

# 第二阶段单样例验证报告

日期：2026-09-12。结论：**报告正文 → 局部安全性质 → 类型化约束 → 代码绑定 → 求解检查，这条最小链路可行。第二阶段整体尚未完成。**

## 输入与隔离

- Panoptic Hypovault 第 461 号报告，submission UID `aHe7XWv2GNE`。
- 使用项目外整理目录中的 `report.json` 和 `contract.flattened.t.sol`；核对配对 UID、`exact_submission` 状态及代码 SHA-256。
- 抽取时只提供报告正文，不提供 PoC、修复建议或报告有效性标签。
- 复用 `opencode-go/deepseek-v4-flash`，不加载或打印密钥。模型调用关闭外部插件、禁止工具使用。
- 不调用 InvCon/Trace2Inv，不修改 Rust、Solar、运行入口或其他阶段。

## 实测结果

模型从报告中提取：

```text
安全性质：actual_token1_exposure = short_token1 - long_token1
代码公式：actual_token1_exposure = long_token1 - short_token1
```

依据是报告明确说明短仓权利金是金库应收、长仓权利金是金库应付。两项原文引用均通过逐字匹配检查。模型成功抽取用时 28.442 秒。

首次获得的模型输出未满足布尔约束类型，被校验器拒绝。明确要求顶层为等式后重试成功；没有用手写声明替代模型输出。独立参考公式仅用于求解回归对照。

| 检查 | 实测 | 含义 |
|---|---|---|
| 原公式，固定 PoC 的短仓 100 ether、长仓 40 ether 输入，寻找安全性质违反 | SAT | 应为 +60，代码局部敞口为 -60，单位为 token1 的 ether 缩放基础单位 |
| 修正减法顺序，寻找任意 uint128 输入范围内的违反 | UNSAT | 在该局部模型中修正公式满足提取的性质 |
| 修正公式下检查输入范围非空 | SAT | 避免不可行前提导致的空真 |
| 原公式、零权利金，检查安全性质成立 | SAT | 不把没有差异的零值情况当作违反 |

独立离线测试 8/8 通过，覆盖类型错误、未知符号、虚构原文依据、缺失代码绑定及错误抽取结果不能通过对照检查。原工程 `cargo test --all-targets --offline` 17/17 通过，仅有现存 Solar 未使用函数警告。

## 不能据此宣称的内容

1. 这不是完整 Solidity 符号执行，只建模转为 int256 后的局部权利金减法。uint128 输入的差值在 int256 范围内，因此这里可以使用有界输入的数学整数模型。
2. 使用的是展开 PoC，不是第一阶段切片；切片接口尚未验证。
3. 没有验证价格转换、敞口归零、其他头寸、最终 NAV 的误差倍数、提款或资金损失。
4. 报告声称的下游影响目前保留为文本和未解决项，还未生成完整效果约束。
5. 模型的 `unresolved` 是抽取阶段的备注，不是已核实事实；其中“不提供 PoC”仅指抽取输入。任何提到的额外建模因素都未作为约束前提。
6. 一份报告不能证明通用抽取准确率；本例正文还直接给出了公式，不能代表隐含安全性质同样容易提取。代码绑定也是专用适配器。

## 文件

- 原始模型输出：[model-claim.json](/root/sc_slicer_standalone/runs/report_constraints/panoptic_461_smoke_20260912_02/model-claim.json)
- 输入、类型化性质、源码位置、求解证据及边界：[constraints.json](/root/sc_slicer_standalone/runs/report_constraints/panoptic_461_smoke_20260912_02/constraints.json)
- 复跑及测试命令：[README.md](/root/sc_slicer_standalone/tools/report_constraints/README.md)

下一步宜选一份正文没有直接公式的报告，验证隐含安全性质推导；再做只读切片绑定和报告效果约束。暂不引入微调、知识库或论文工具运行依赖。
